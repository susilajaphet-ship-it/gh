CREATE DATABASE IF NOT EXISTS susilatech CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE susilatech;
CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(180) NOT NULL, category VARCHAR(80) NOT NULL,
 description TEXT, price DECIMAL(12,2) NOT NULL DEFAULT 0, stock INT NOT NULL DEFAULT 0,
 image_url TEXT, featured TINYINT(1) NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS customers (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, phone VARCHAR(40),
 email VARCHAR(190), address TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY, customer_name VARCHAR(150) NOT NULL, phone VARCHAR(40) NOT NULL,
 email VARCHAR(190), address TEXT, items_json JSON NOT NULL, total DECIMAL(12,2) NOT NULL,
 status ENUM('Pending','Confirmed','Processing','Dispatched','Completed','Cancelled') DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS expenses (
 id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(180) NOT NULL, amount DECIMAL(12,2) NOT NULL,
 category VARCHAR(100), notes TEXT, expense_date DATE NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(190) UNIQUE NOT NULL,
 password_hash VARCHAR(255) NOT NULL, role ENUM('admin','staff') DEFAULT 'staff',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO products (name,category,description,price,stock,image_url,featured) VALUES
('Business Laptop','Laptops','Laptop for work, study and business.',1250000,8,'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=85',1),
('Desktop Computer Set','Desktops & CPUs','Desktop computer and monitor for office use.',980000,5,'https://images.unsplash.com/photo-1587831990711-23ca6441447b?auto=format&fit=crop&w=900&q=85',1),
('Android Smartphone','Smartphones','Modern smartphone; confirm model and storage.',420000,12,'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=85',1),
('Office Printer','Printers','Everyday printing solution for documents.',380000,4,'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&w=900&q=85',1),
('Large Format Printer','Printing Machines','Equipment for signage and graphics.',2450000,2,'https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=900&q=85',0),
('Logo & Poster Printing','Branding & Posters','Logo, poster and branded print services.',85000,20,'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=900&q=85',1),
('Wireless Accessories Kit','Accessories','Keyboard, mouse, adapters and accessories.',95000,18,'https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=85',0);
