# SusilaTech full-stack website starter

## Features
- Responsive electronics storefront with animated floating words, hero image, scrolling text ticker and product imagery.
- Categories: laptops, desktop/CPU, smartphones, printers, printing machines, logos/posters and accessories.
- Search, product cards, cart, quantity controls and checkout.
- Node.js + Express REST API, MySQL tables for products, customers, orders, expenses and users.
- Login API and protected admin APIs for dashboard summary, customers, orders, product creation and expenses.

## Run on Windows
1. Install Node.js 18+ and MySQL.
2. Open Command Prompt in the extracted folder.
3. Import the schema using MySQL Workbench, or run:
   `mysql -u root -p < schema.sql`
4. Copy `.env.example` to `.env`; enter your MySQL password and a long random `JWT_SECRET`.
5. Run `npm install`, then `npm start`.
6. Open `http://localhost:3000`.

## Administrator setup
Generate a password hash:
`node -e "const b=require('bcryptjs'); console.log(b.hashSync('YOUR_STRONG_PASSWORD',12))"`
Then insert an admin user:
`INSERT INTO susilatech.users(name,email,password_hash,role) VALUES('Admin','admin@susilatech.co.tz','PASTE_HASH_HERE','admin');`
Login endpoint: `POST /api/auth/login` with JSON `{ "email":"...", "password":"..." }`. Use the returned token as `Authorization: Bearer TOKEN` on `/api/admin/*`.

## Before publishing
- Set `WHATSAPP_NUMBER` in `public/app.js` to your real international number in digits only (e.g. 2557XXXXXXXX).
- Replace sample product prices, stock and image URLs with your real catalogue.
- Sample photos load from Unsplash and require internet access.
- The public storefront works with sample products without a database, but orders are only stored when MySQL and the backend are configured.
- Admin APIs are included, but a complete visual admin console, payment integration, shipping/tax rules, rate limiting, HTTPS, backups and production security review remain to be implemented before live commerce.
